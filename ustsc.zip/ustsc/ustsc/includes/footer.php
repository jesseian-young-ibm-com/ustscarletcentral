<!-------------- FOOTER start ---------->

<footer class="footer">

	<div class="row1">
		<div class="footer-col-1">
			<a href="mainhome.php" class="logo"><img src="assets/ustlogo.png" alt="" class="ustlogo"></a>
		</div>

		<div class="footer-col-2">
			<h4>Location</h4>
			<p>4J, 4TH FLOOR TAN YAN KEE BUILDING, UST ESPANA BOULEVARD, </p>
			<p> SAMPALOC MANILA PHILIPPINES, 1015</p>
		</div>
	</div>

</footer>

<script src="https://cdn.jsdelivr.net/npm/sweetalert2@8"></script>

<!-- Jquery Library file -->
<script src="./js/jquery3.6.0.min.js"></script>

<!-- Custom Javascript file -->
<script src="./js/main.js"></script>
</body>

</html>