<script src="https://cdn.jsdelivr.net/npm/sweetalert2@8"></script>

<!-- Jquery Library file -->

<script src="./js/jquery3.6.0.min.js"></script>

<!-- Custom Javascript file -->
<script src="./js/main.js"></script>
</body>

</html>