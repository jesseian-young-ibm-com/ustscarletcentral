<?php
include "./includes/header.php";
?>
<head>
<style>
	body {
		background-image: url('assets/scbg.jpg');
		background-repeat: no-repeat;
		background-attachment: fixed;
		background-size: cover;
	}

  .google-maps {
    position: relative;
    padding-bottom: 50%;
    height: 0;
    overflow: hidden;
  }
  .google-maps iframe {
    position: absolute;
    top: 0;
    left: 0;
    width: 100% !important;
    height: 85% !important;
  }
a:hover{
	color:#580000;
	background-color: transparent;
	text-decoration: underline;

}

a:active{
	color:#580000;
	background-color: transparent;
	text-decoration: none;

}

</style>



</head>


<body>
<meta name="viewport" content="width=device-width,initial-scale=1,maximum-scale=1,user-scalable=no">
<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
<meta name="HandheldFriendly" content="true">

	<link href='https://fonts.googleapis.com/css?family=Trykker' rel='stylesheet'>

	<h1 style="color:#000000;line-height:5;font-family: 'Trykker';font-size: 3vw;margin-left: 95px;">Got Some Inquiries? Let's work together!</h1>

	<a href="https://www.facebook.com/iloveustscarlet" target="_blank" style="color:#000000;"><img src="assets/facebook.png" style="width:60px;height:60px;margin-left: 95px;"></a>


	<p style="color:#000000;margin-left: 180px;margin-top:-60px;margin-bottom: 60px;font-family: 'Trykker';">UST Scarlet Central<br>@iloveustscarlet<br><a href="https://www.facebook.com/iloveustscarlet" target="_blank" style="color:#000000;">https://www.facebook.com/iloveustscarlet</a></p>


	<!-- <h2 style="color:#000000;line-height:5;font-family: 'Trykker';font-size: 50px;margin-left: 95px;font-size: 25px;">Got Some inquiries? Let's work together!</h2> -->

	<a href="https://www.twitter.com/scarletcentral?s=21" target="_blank" style="color:#000000;"><img src="assets/twt.png" style="width:80px;height:80px;margin-left: 85px;"></a>

	<p style="color:#000000;margin-left: 180px;margin-top:-75px;margin-bottom: 60px;font-family: 'Trykker';">UST Scarlet Central<br>@scarletcentral<br><a href="https://www.twitter.com/scarletcentral?s=21" target="_blank" style="color:#000000;">https://www.twitter.com/scarletcentral?s=21</a></p>

	<a href="https://www.instagram.com/scarletcentral/?hl=en" target="_blank" style="color:#000000;"><img src="assets/ig.png" style="width:90px;height:90px;margin-left: 90px;"></a>

	<p style="color:#000000;margin-left: 180px;margin-top:-75px;margin-bottom: 60px;font-family: 'Trykker';">UST Scarlet Central<br>@scarletcentral<br><a href="https://www.instagram.com/scarletcentral/?hl=en" target="_blank" style="color:#000000;">https://www.instagram.com/scarletcentral/?hl=en</a></p>
	<div class="google-maps">

  <iframe
    src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3860.7860054209887!2d120.9861156148405!3d14.611262889795722!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3397b60071fcebb3%3A0xfdfb6b896ebe80db!2sTan%20Yan%20Kee%20Student%20Center!5e0!3m2!1sen!2sph!4v1646590692849!5m2!1sen!2sph""
    width="600"
    height="450"
    style="border:0;"
    allowfullscreen=""
    loading="lazy"
  ></iframe>
</div>
	

</body>





<button onclick="topFunction()" id="myBtn" title="Go to top">Back to Top</button>

<?php
include "./includes/footer.php";
?>