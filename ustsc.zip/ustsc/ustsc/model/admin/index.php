<?php

header("Location: ../../mainhome.php");
